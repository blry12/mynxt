import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflix.io/mynxt/texts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflix.io/mynxt/texts/wizard_notify_omega.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
